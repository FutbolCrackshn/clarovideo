$(document).ready(function () {

    $('button.embed-link').on('click', function () {
        let link = $(this).attr("datatype")
        let iframe = $('.embed-responsive iframe')
        let currentLink = iframe.attr("src")
        if (link !== currentLink) {
            iframe.attr("src", link)
            $('button.embed-link.btn-success').removeClass("btn-success").addClass("btn-primary")
            $(this).addClass("btn-success").removeClass("btn-primary")

        }
    })
})
